export default {
	"#jsrg_zoushi:die": "年老色衰了吗？",
	"#jsrg_zhangren:die": "老臣，绝不事二主！",
	"#jsrg_huangzhong:die": "不得不服老啦~",
	"#jsrg_liuhong:die": "权利的滋味，让人沉沦……",
};
