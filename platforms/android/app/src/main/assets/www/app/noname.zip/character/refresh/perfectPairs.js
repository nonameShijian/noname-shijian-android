export default {
	sunben: ["zhouyu", "taishici", "re_taishici", "daqiao"],
	re_xushu: ["zhaoyun", "sp_zhugeliang"],
	re_guohuai: ["xiahouyuan", "zhanghe"],
};
