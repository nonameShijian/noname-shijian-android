/**
 * 无名杀内部所需要的数据结构
 */

export * as PromiseErrorHandler from "./promise-error-handler/index.js";
