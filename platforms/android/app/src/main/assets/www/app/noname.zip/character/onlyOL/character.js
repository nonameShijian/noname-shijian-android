const characters = {
	ol_sb_jiangwei: ["male", "shu", 4, ["olsbzhuri", "olsbranji"]],
	ol_caozhang: ["male", "wei", 4, ["oljiangchi"], ["die_audio:xin_caozhang"]],
	ol_jianyong: ["male", "shu", 3, ["olqiaoshui", "jyzongshi"], ["tempname:re_jianyong", "die_audio:re_jianyong"]],
	ol_lingtong: ["male", "wu", 4, ["olxuanfeng"], ["die_audio:re_lingtong"]],
	ol_sb_guanyu: ["male", "shu", 4, ["olsbweilin", "olsbduoshou"]],
	ol_sb_taishici: ["male", "wu", 4, ["olsbdulie", "olsbdouchan"]],
	ol_gaoshun: ["male", "qun", 4, ["olxianzhen", "decadejinjiu"], ["die_audio:re_gaoshun"]],
	ol_sb_yuanshao: ["male", "qun", 4, ["olsbhetao", "olsbshenli", "olsbyufeng", "olsbshishou"], ["zhu"]],
	ol_yufan: ["male", "wu", 3, ["olzongxuan", "olzhiyan"], ["tempname:re_yufan", "die_audio:re_yufan"]],
	ol_chengpu: ["male", "wu", 4, ["dclihuo", "olchunlao"], ["tempname:xin_chengpu", "die_audio:xin_chengpu"]],
	ol_wangyi: ["female", "wei", 3, ["olzhenlie", "olmiji"]],
	ol_sb_pangtong: ["male", "shu", 3, ["olsbhongtu", "olsbqiwu"]],
	ol_fazheng: ["male", "shu", 3, ["olxuanhuo", "olenyuan"]],
};

export default characters;
