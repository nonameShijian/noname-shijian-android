export default {
	lijue: ["guosi", "jiaxu"],
	zhangji: ["zhangxiu", "drlt_zhangxiu", "zoushi"],
	xf_sufei: ["ganning"],
	//baosanniang:['guansuo'],
	simahui: ["pangdegong"],
	zhangqiying: ["zhanglu"],
	pangtong: ["zhugejin"],
	taishici: ["liuyao", "kongrong"],
	//zhaotongzhaoguang:['zhaoyun','mayunlu'],
};
