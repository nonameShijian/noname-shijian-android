const pinyins = {};
export default pinyins;
