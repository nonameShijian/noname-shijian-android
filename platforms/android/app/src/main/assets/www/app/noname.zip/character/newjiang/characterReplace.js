const characterReplaces = {
	liwan: ["ol_liwan", "liwan"],
	wuxian: ["wuxian", "clan_wuxian"],
	simafu: ["mb_simafu", "simafu", "yj_simafu"],
	xuangongzhu: ["yj_xuangongzhu", "xuangongzhu"],
	kebineng: ["kebineng", "ol_kebineng", "ddd_kebineng"],
	hanlong: ["hanlong", "jd_hanlong"],
};

export default characterReplaces;
