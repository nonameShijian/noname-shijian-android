const characters = {
	wangcan: ["male", "qun", 3, ["xinfu_sanwen", "xinfu_qiai", "xinfu_denglou"]],
	sp_taishici: ["male", "qun", 4, ["xinfu_jixu"]],
	re_jsp_pangtong: ["male", "wu", 3, ["xinfu_guolun", "xinfu_songsang"]],
	lvdai: ["male", "wu", 4, ["xinfu_qinguo"]],
	re_zhangliang: ["male", "qun", 4, ["xinfu_jijun", "xinfu_fangtong"]],
	lvqian: ["male", "wei", 4, ["xinfu_weilu", "xinfu_zengdao"]],
	panjun: ["male", "wu", 3, ["xinfu_guanwei", "xinfu_gongqing"]],
	duji: ["male", "wei", 3, ["xinfu_andong", "xinfu_yingshi"]],
	zhoufang: ["male", "wu", 3, ["xinfu_duanfa", "xinfu_youdi"]],
	yanjun: ["male", "wu", 3, ["xinfu_guanchao", "xinfu_xunxian"]],
	liuyao: ["male", "qun", 4, ["xinfu_kannan", "twniju"], ["zhu"]],
	liuyan: ["male", "qun", 3, ["xinfu_tushe", "xinfu_limu"]],
};

export default characters;
