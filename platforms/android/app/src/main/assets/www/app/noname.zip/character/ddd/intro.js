const characterIntro = {};

export default characterIntro;
