const characterReplaces = {
	wuban: ["clan_wuban", "dc_wuban", "wuban", "xin_wuban"],
};

export default characterReplaces;
