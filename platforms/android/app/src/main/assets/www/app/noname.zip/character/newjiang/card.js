import { lib, game, ui, get, ai, _status } from "../../noname.js";

const cards = {
	lukai_spade: { fullskin: true },
	lukai_heart: { fullskin: true },
	lukai_diamond: { fullskin: true },
	lukai_club: { fullskin: true },
};

export default cards;
