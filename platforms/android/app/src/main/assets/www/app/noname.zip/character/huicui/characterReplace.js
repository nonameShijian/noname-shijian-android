const characterReplaces = {
	lifeng: ["dc_lifeng", "lifeng"],
	liuyong: ["liuyong", "jsrg_liuyong"],
	qiaorui: ["qiaorui", "tw_qiaorui"],
	gaoxiang: ["gaoxiang", "jsrg_gaoxiang"],
	zhangchu: ["zhangchu", "jsrg_zhangchu"],
	mamidi: ["mamidi", "xin_mamidi"],
	re_chunyuqiong: ["re_chunyuqiong", "chunyuqiong", "jsrg_chunyuqiong"],
	chengui: ["chengui", "mb_chengui"],
};

export default characterReplaces;
