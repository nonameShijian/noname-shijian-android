const characterReplaces = {
	lifeng: ["dc_lifeng", "lifeng"],
};

export default characterReplaces;
