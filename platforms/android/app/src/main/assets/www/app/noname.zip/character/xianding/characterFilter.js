import { lib, game, ui, get, ai, _status } from "../../noname.js";

const characterFilters = {
	// leitong(mode) {
	// 	return mode != "identity" && mode != "guozhan";
	// },
	// wulan(mode) {
	// 	return mode != "identity" && mode != "guozhan";
	// },
};

export default characterFilters;
