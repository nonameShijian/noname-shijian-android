export default {
	wujing: ["sunce", "sunben", "wuguotai"],
};
