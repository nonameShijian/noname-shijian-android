export default {
	nanhualaoxian: ["zuoci", "yuji"],
	re_nanhualaoxian: ["zuoci", "yuji"],
};
