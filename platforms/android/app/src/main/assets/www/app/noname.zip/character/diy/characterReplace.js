const characterReplaces = {
	key_yuri: ["key_yuri", "sp_key_yuri"],
	sp_key_kanade: ["sp_key_kanade", "kanade"],
};

export default characterReplaces;
