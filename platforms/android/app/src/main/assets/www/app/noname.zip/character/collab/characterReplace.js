const characterReplaces = {};

export default characterReplaces;
