/**
 * 无名杀内部构建所需要用到的接口
 */

export { PromiseErrorHandler } from "./promise-error-handler";
