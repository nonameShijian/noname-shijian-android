const characterReplaces = {
	sunhao: ["sunhao", "std_sunhao"],
	lvlingqi: ["lvlingqi", "std_lvlingqi"],
	chengyu: ["chengyu", "std_chengyu", "dc_sb_chengyu"],
	fanyufeng: ["fanyufeng", "std_fanyufeng"],
};

export default characterReplaces;
