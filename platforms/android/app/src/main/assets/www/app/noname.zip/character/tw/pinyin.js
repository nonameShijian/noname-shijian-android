const pinyins = {
	凯撒: ["Caesar"],
	难升米: ["Nashime"],
};
export default pinyins;
