const characterReplaces = {
	jin_yanghu: ["jin_yanghu", "dc_yanghu", "sp_yanghu", "std_dc_yanghu"],
	jiachong: ["dc_jiachong", "jin_jiachong", "jiachong", "mb_jiachong"],
	yangyan: ["yangyan", "old_yangyan"],
	yangzhi: ["yangzhi", "old_yangzhi"],
	zhongyan: ["zhongyan", "clan_zhongyan"],
	simazhou: ["simazhou", "mb_simazhou"],
	jin_xiahouhui: ["jin_xiahouhui", "jd_jin_xiahouhui"],
};

export default characterReplaces;
