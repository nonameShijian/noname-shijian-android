const characterReplaces = {
	yanghu: ["jin_yanghu", "dc_yanghu", "sp_yanghu", "std_dc_yanghu"],
	jiachong: ["dc_jiachong", "jin_jiachong", "jiachong"],
	yangyan: ["yangyan", "old_yangyan"],
	yangzhi: ["yangzhi", "old_yangzhi"],
	zhongyan: ["zhongyan", "clan_zhongyan"],
};

export default characterReplaces;
