"use strict";
game.import("extension", function (lib, game, ui, get, ai, _status) {
	return {
		name: "SJ Settings",
		editable: false,
		content: function (config, pack) {
			
		},
		precontent: function () {
			lib.arenaReady.push(() => {
				game.removeExtension('SJ Settings');
				setTimeout(() => {
					alert('SJ Settings已经迁移到Settings扩展，正在重启');
					lib.config.extensions.remove('SJ Settings');
					lib.config.extensions.add('Settings');
					game.saveConfigValue('extensions');
					game.reload();
				}, 2000);
			})
		},
		config: {
		},
		package: {
			intro: "本扩展已经迁移到Settings扩展，请及时删除",
			author: "诗笺",
			diskURL: "",
			forumURL: "",
			version: "1.6",
		}
	};
});