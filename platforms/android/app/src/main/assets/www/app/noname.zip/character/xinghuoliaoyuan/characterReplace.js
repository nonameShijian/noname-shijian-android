const characterReplaces = {
	duji: ["duji", "re_duji", "ns_duji"],
	sp_taishici: ["sp_taishici", "re_sp_taishici"],
	mazhong: ["mazhong", "re_mazhong"],
	wenpin: ["wenpin", "re_wenpin"],
	liuyan: ["liuyan", "jsrg_liuyan", "ol_liuyan"],
};

export default characterReplaces;
