export default {
	tw_liufuren: ["yuanshao"],
	tw_xiahoushang: ["caopi"],
};
