window.noname_update = {
	version: "1.10.11.1",
	update: "NULL", //新版本更新文件较多，直接强制进行全量更新
	changeLog: [
		"整合@Rintim @mengxinzxz @nonameShijian @lieren2023 @itsnoteasytonameaccount @kuangshen04 @IceCola97 @PZ157 @universe-st @Iking123 @copcap @nineMangos 的Pull Request",
		"OL族王广、族王明山、界王异、刘辟、SP孙策；十周年曹芳、武关羽、神华佗、SP甄姬",
		"手杀SP毌丘俭、曹髦、成济、李昭&焦伯；海外服颜良、文丑、袁谭",
		"添加“无限火力”单挑模式",
		"拆分“技能的消耗”和“技能的效果”，加入“按点卖血”等同时机多次发动技能的机制，逐步淘汰direct:true的写法",
		"其他AI优化与bug修复",
	],
	files: [],
};
