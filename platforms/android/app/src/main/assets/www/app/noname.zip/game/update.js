window.noname_update = {
	version: "1.10.12",
	update: "NULL", //新版本更新文件较多，直接强制进行全量更新
	changeLog: [
		"吴懿(十周年地主)、族钟繇、关樾、吴普、星孙坚、令狐愚、司马孚、宣公主、徐琨",
		"给无名杀的所有技能语音添加对应的台词",
		"创建Character类",
		"bug修复",
	],
	files: [],
};
