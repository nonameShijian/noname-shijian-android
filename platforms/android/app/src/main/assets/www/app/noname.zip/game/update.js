window.noname_update={
	version:'1.10.6.1',
	update:'1.10.6',
	changeLog:[
		'整合@mengxinzxz @PZ157 @universe-st @Ansolve @Rintim @nonameShijian @copcap @kuangshen04 的Pull Request',
		'《江山如故·合》武将包',
		'其他AI优化与bug修复',
	],
	files:[
		'card/standard.js',
		'card/yongjian.js',

		'character/extra.js',
		'character/huicui.js',
		'character/jsrg.js',
		'character/mobile.js',
		'character/offline.js',
		'character/rank.js',
		'character/refresh.js',
		'character/sb.js',
		'character/shenhua.js',
		'character/sp.js',
		'character/sp2.js',
		'character/standard.js',
		'character/tw.js',
		'character/xianding.js',

		'game/game.js',
		'game/source.js',

		'mode/boss.js',

		'noname.js',

		'noname/game/index.js',

		'noname/get/index.js',
		'noname/get/is.js',

		'noname/init/cordova.js',
		'noname/init/import.js',
		'noname/init/index.js',

		'noname/library/index.js',

		'noname/library/element/content.js',
		'noname/library/element/gameEvent.js',
		'noname/library/element/gameEventPromise.js',
		'noname/library/element/vcard.js',

		'noname/ui/index.js',

		'noname/util/struct/promise-error-handler/chrome.js',
		'noname/util/struct/promise-error-handler/unknown.js',
	]
};
