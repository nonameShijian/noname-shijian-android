window.noname_update = {
	version: "1.10.11.2",
	update: "NULL", //新版本更新文件较多，直接强制进行全量更新
	changeLog: [
		"整合@Rintim @nonameShijian  @copcap @PZ157 @mengxinzxz @lieren2023 的Pull Request",
		"bug修复",
	],
	files: [],
};
