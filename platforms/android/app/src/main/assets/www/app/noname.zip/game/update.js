window.noname_update={
	version:'1.10.3.1',
	update:'1.10.3',
	changeLog:[
		'整合@nonameShijian @PZ157 @MDYY1 @mengxinzxz @lieren2023 @Lucilor @kuangshen04 @BauxiteAI @copcap @Tipx-L @xiaoas @Rintim @universe-st的Pull Request',
		'新机制：武将名称前缀的高亮显示',
		'将谋攻篇武将加入同名武将切换',
		'lib.nature向下兼容和相关函数更改',
		'其他AI优化与bug修复',
	],
	files:[
		'character/extra.js',
		'character/mobile.js',
		'game/game.js',
	]
};
