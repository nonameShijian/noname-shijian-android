const characterReplaces = {
    ty_guanxing: ["ty_guanxing", "std_guanxing"],
    ty_fengxí: ["ty_fengxí", "tw_fengxí"],
    ty_zhangnan: ["ty_zhangnan", "tw_zhangnan"],
    ty_chenshi: ["ty_chenshi", "chenshi"],
    ty_anying: ["ty_anying", "ty_anyingx"],
};

export default characterReplaces;
