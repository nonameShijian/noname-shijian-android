const characterReplaces = {
	tw_caocao: ["tw_caocao", "jsrg_caocao", "yj_caocao", "ol_jsrg_caocao"],
	mateng: ["tw_mateng", "mateng", "std_mateng", "dc_mateng"],
	tw_xiahouen: ["tw_xiahouen", "jsrg_xiahouen"],
	jiangji: ["dc_jiangji", "tw_jiangji", "jiangji"],
	baoxin: ["tw_baoxin", "baoxin"],
	yanxiang: ["yanxiang", "tw_yanxiang"],
	liwei: ["liwei", "tw_liwei"],
	tw_jiling: ["jiling", "dc_jiling", "tw_jiling", "std_jiling", "yj_jiling"],
	tw_zhangji: ["tw_zhangji", "ol_tw_zhangji"],
	yuejiu: ["yuejiu", "dc_yuejiu"],
};

export default characterReplaces;
