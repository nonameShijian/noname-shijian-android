const characterReplaces = {
	tw_caocao: ["tw_caocao", "jsrg_caocao", "yj_caocao"],
	mateng: ["tw_mateng", "mateng", "std_mateng"],
	xiahouen: ["tw_xiahouen", "jsrg_xiahouen"],
	jiangji: ["dc_jiangji", "tw_jiangji", "jiangji"],
	baoxin: ["tw_baoxin", "baoxin"],
	yanxiang: ["yanxiang", "tw_yanxiang"],
	liwei: ["liwei", "tw_liwei"],
};

export default characterReplaces;
