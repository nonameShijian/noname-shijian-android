export default {
	simazhao: ["simayi", "jin_simayi", "jin_wangyuanji"],
	xugong: ["yanbaihu"],
};
