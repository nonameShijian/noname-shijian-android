'use strict';
game.import('mode',function(lib,game,ui,get,ai,_status){
	return {
		name:'realtime',
		start:function(){

		},
		game:{

		}
	};
});
