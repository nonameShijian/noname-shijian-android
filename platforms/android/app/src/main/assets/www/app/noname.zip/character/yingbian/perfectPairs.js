export default {
	jin_simayi: ["jin_zhangchunhua", "shibao", "duyu"],
	jin_simazhao: ["jin_wangyuanji"],
	jin_simashi: ["jin_xiahouhui", "jin_yanghuiyu"],
	xuangongzhu: ["duyu"],
};
