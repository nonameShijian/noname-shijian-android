window.noname_update = {
	version: "1.10.17.3",
	update: "NULL", //新版本更新文件较多，直接强制进行全量更新
	changeLog: [
		"国战更新版本，将国战模式拆分并修复了大量bug",
		"新武将，新函数，bug修复，AI优化与台词调整，具体请查看game/updateLog.md",
		"同时本次更新修改了部分默认配置，斗地主增加了新选项",
		"界面和部分动画效果方面进行了优化与修改，具体请查看game/updateLog.md",
		"最后是继续为未来的武将解耦做准备喵"
	],
	files: [],
};
