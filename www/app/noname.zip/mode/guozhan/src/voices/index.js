import character from "./character/index.js";
import rest from "./rest.js";

export default {
	...rest,
	...character,
};
