export default {
	"#gz_dengai:die": "君不知臣，臣不知君，罢了……罢了……",
	"#tuntian_gz_dengai1": "积谷于此，以制四方。",
	"#tuntian_gz_dengai2": "留得良田在，何愁不破敌？",
	"#jixi_gz_dengai1": "哪里走！！",
	"#jixi_gz_dengai2": "谁占到先机，谁就胜了。",
	"#ziliang1": "吃饱了，才有力气为国效力。",
	"#ziliang2": "兵，断不可无粮啊。",

	"#gz_jiangwei:die": "臣等正欲死战，陛下何故先降！",

	"#tiaoxin_gz_jiangwei1": "小小娃娃，乳臭未干。",
	"#tiaoxin_gz_jiangwei2": "快滚回去，叫你主将出来！",
	"#yizhi1": "天文地理，丞相所教，维铭记于心。",
	"#yizhi2": "哪怕只有一线生机，我也不会放弃！",
	"#tianfu1": "丞相已教我识得此计！",
	"#tianfu2": "哼，有破绽！",

	"#gz_xusheng:die": "可怜一身胆略，尽随一抔黄土……",
	"#yicheng1": "不怕死，就尽管放马过来！",
	"#yicheng2": "待末将布下疑城，以退曹贼。",

	"#qianhuan1": "幻变迷踪，虽飞鸟亦难觅踪迹。",
	"#qianhuan2": "幻化于阴阳，藏匿于乾坤。",
};
