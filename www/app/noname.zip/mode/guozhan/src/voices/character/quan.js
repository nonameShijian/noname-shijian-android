export default {
	"#jianglue1": "奇谋为短，将略为要。",
	"#jianglue2": "为将者，需有谋略。",
};
