export default {
	"#yingyang1": "此战，我必取胜！",
	"#yingyang2": "相斗之趣，吾常胜之。",
};
