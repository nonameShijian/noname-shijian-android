export default {
	junling1: {
		type: "junling",
		vanish: true,
		derivation: "guozhan",
	},
	junling2: {
		type: "junling",
		vanish: true,
		derivation: "guozhan",
	},
	junling3: {
		type: "junling",
		vanish: true,
		derivation: "guozhan",
	},
	junling4: {
		type: "junling",
		vanish: true,
		derivation: "guozhan",
	},
	junling5: {
		type: "junling",
		vanish: true,
		derivation: "guozhan",
	},
	junling6: {
		type: "junling",
		vanish: true,
		derivation: "guozhan",
	},
	zhulian_card: {
		cardimage: "wuzhong",
	},
};
