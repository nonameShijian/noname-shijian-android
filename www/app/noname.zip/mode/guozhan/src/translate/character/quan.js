export default {
	gz_cuimao: "崔琰毛玠",
	gz_yujin: "于禁",
};

export const sort = ["guozhan_quan", "君临天下·权"];
