export default {};

export const sort = ["guozhan_zhen", "君临天下·阵"];
