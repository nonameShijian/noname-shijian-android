export default {};

export const sort = ["guozhan_shi", "君临天下·势"];
