import sort from "./sort.js";
import normal from "./normal.js";
import zhen from "./zhen.js";
import yingbian from "./yingbian.js";

export default {
	...sort,
	...normal,
	...zhen,
	...yingbian,
};
