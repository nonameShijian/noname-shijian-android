import character from "./character/index.js";

export default {
	...character,
};
