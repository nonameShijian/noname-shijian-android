import App from "./App.vue";

export default {
	国战模式: App,
};
