export * as rank from "./rank.js";
export * as pile from "./pile.js";

export const junList = ["liubei", "zhangjiao", "sunquan", "caocao", "jin_simayi"];
