export const rootURL = new URL("./", import.meta.url);
