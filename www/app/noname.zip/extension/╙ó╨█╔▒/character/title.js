export default {
	yxs_qinqiong: "Sukincen",
};
