const list = [
	["diamond", "5", "monkey"],
	["heart", "9", "jiuwei"],
	["heart", "2", "xuelunyang"],
	["spade", "6", "kuwu"],
	["diamond", "4", "shoulijian"],
	["spade", "4", "shoulijian"],
	["club", "3", "mianju"],
];

export default list;
