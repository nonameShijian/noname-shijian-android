const translate = {
	monkey: "猴子",
	monkey_info: "猴子偷桃：当场上有其他角色使用【桃】时，你可以弃掉【猴子】，阻止【桃】的结算并将其收为手牌。",
	mianju: "漩涡面具",
	mianju_info: "<font color=#f00>锁定技</font> 你的武将牌不能被翻面。",
	shoulijian: "手里剑",
	shoulijian_info: "出牌阶段，对一名距离1以外的角色使用，令其弃置一张装备牌或受到1点伤害。",
	kuwu: "苦无",
	kuwu_info: "<font color=#f00>锁定技</font> 每当你使用【杀】造成一次伤害，受伤角色须弃置一张牌。",
	xuelunyang: "写轮眼",
	xuelunyang_info: "回合开始时，你可以选择一名其他角色，然后获得其一个技能直到回合结束。",
	jiuwei: "九尾",
	jiuwei_info: "（收集查克拉）回合结束时，若你已受伤，你可回复1点体力，否则摸一张牌。",
};

export default translate;
