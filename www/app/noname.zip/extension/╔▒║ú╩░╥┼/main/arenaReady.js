import { lib, game, ui, get, ai, _status } from "./utils.js";
// import { Character } from "../../../noname/library/element/index.js";

export function arenaReady() {
	// if (lib.skill.siji && lib.skill.ciqiu) {
	// 	const hanlong = {
	// 		sex: "male",
	// 		group: "wei",
	// 		hp: 4,
	// 		skills: ["ciqiu", "siji"],
	// 		img: "extension/轩辕剑/image/character/swd_hanlong.jpg",
	// 	};
	// 	lib.character.swd_hanlong = new Character(hanlong);
	// 	lib.characterPack.swd.swd_hanlong = hanlong;
	// }
}
