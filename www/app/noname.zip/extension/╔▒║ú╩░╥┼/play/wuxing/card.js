const card = {
	wuxingpan: {
		type: "equip",
		subtype: "equip5",
		skills: ["wuxingpan_skill"],
		fullskin: true,
	},
};

export default card;
