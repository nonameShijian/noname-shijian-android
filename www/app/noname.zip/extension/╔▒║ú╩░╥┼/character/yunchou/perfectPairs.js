export default {
	diy_luxun: ["diy_lukang"],
};
