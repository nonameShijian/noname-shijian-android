export default {
	hsfashu: 0.5,
	hszuzhou: 0.5,
	hsmengjing: 0.5,
	hsbaowu: 0.5,
	hsdusu: 0.5,
	hsshenqi: 0.5,
	hsyaoshui: 0.5,
	hsqingyu: 0.5,
	hsqizhou: 0.5,
	hsjixie: 0.5,
};
