const characterTitle = {
	hs_aiqinvyao: "#bSnonamekill",
};

export default characterTitle;
