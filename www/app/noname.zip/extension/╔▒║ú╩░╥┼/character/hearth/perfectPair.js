const perfectPair = {
	hs_sthrall: ["hs_totemic", "hs_alakir", "hs_neptulon", "hs_yngvar"],
	hs_anduin: ["hs_wvelen", "hs_mijiaojisi"],
	hs_jaina: ["hs_antonidas"],
	hs_malfurion: ["hs_malorne"],
};

export default perfectPair;
