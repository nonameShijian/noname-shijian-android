const characterIntro = {
	gw_huoge: "那个老年痴呆？不知道他是活着还是已经被制成标本了！",
	gw_aisinie: "树精皇后有着熔银做成的眼睛，冰冷铸钢的心脏。",
	gw_gaier: "画作应该要传达情绪，而不是字句。",
	gw_enxier: "我可没什么耐心，最好小心点，否则脑袋不保！",

	gw_yenaifa: "魔法是艺术、混沌与科学的结合。因为魔法的确是一门技艺也是一种诅咒。",
	gw_telisi: "我可以照顾我自己，相信我。",
	gw_jieluote: "如果要付出这种代价才能拯救世界，那最好还是让世界消逝吧。",
	gw_xili: "我想去哪，就去哪。",
	gw_luoqi: "是个爱国者……还是个货真价实的王八蛋。",
	gw_yioufeisi: "国王还是乞丐，两者有何区别，人类少一个算一个。",
};

export default characterIntro;
