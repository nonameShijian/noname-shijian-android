export default {
	gwmaoxian: 0.5,
};
