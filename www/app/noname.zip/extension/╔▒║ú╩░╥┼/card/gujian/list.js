const list = [
	["spade", 2, "tanhuadong"],
	["club", 1, "molicha"],
	["club", 3, "chunbing"],
	["heart", 12, "yougeng"],
	["heart", 8, "gudonggeng"],
	["heart", 1, "liyutang"],
	["diamond", 4, "mizhilianou"],
	["diamond", 6, "xiajiao"],
	["spade", 3, "qingtuan"],
	["club", 11, "luyugeng"],
	["heart", 4, "mapodoufu"],
	["spade", 8, "yuanbaorou"],

	["spade", 7, "gjyuheng"],
	["club", 4, "mutoumianju"],
	["spade", 2, "heilonglinpian"],
	["spade", 1, "mianlijinzhen"],
	["heart", 13, "yunvyuanshen"],

	["club", 8, "feibiao", "poison"],
	["diamond", 9, "feibiao", "poison"],

	["spade", 3, "bingpotong", "poison"],
	["club", 12, "bingpotong", "poison"],

	["club", 5, "shihuifen"],
	["club", 1, "shihuifen"],
	["spade", 13, "shihuifen"],

	["diamond", 6, "shujinsan"],
	["spade", 2, "shujinsan"],

	["diamond", 6, "ziyangdan"],
	["heart", 1, "ziyangdan"],

	// ['diamond',7,'dinvxuanshuang'],
	["heart", 9, "dinvxuanshuang"],

	["spade", 9, "qiankunbiao"],
	["club", 13, "qiankunbiao"],

	["diamond", 9, "shenhuofeiya"],
	["spade", 7, "longxugou"],

	["heart", 9, "jinlianzhu"],
	["spade", 7, "jinlianzhu"],

	["heart", 6, "liutouge"],
	["club", 6, "liutouge"],

	["club", 6, "liufengsan"],
	["club", 3, "liufengsan"],

	["heart", 13, "shatang", "fire"],
];

export default list;
