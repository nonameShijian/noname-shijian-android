export default {
	food: 0.3,
};
