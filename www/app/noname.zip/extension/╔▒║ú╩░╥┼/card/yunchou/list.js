const list = [
	["heart", 6, "huoshan", "fire"],
	["club", 7, "hongshui"],
	["diamond", 3, "guohe"],

	["diamond", 4, "fudichouxin"],
	["club", 6, "fudichouxin"],
	["spade", 1, "fudichouxin"],
	["club", 7, "shuigong"],
	["club", 8, "shuigong"],
	["club", 8, "guohe"],
	["spade", 9, "shuigong"],
	["heart", 9, "toulianghuanzhu"],
	["club", 10, "toulianghuanzhu"],
	["spade", 13, "guohe"],
	["diamond", 6, "chenhuodajie"],
	["diamond", 9, "chenhuodajie"],
	["club", 3, "chenhuodajie"],

	["club", 13, "suolianjia"],

	["club", 3, "caochuanjiejian"],
	["spade", 7, "caochuanjiejian"],
	["heart", 1, "geanguanhuo"],
	["spade", 6, "geanguanhuo"],
	["heart", 4, "shezhanqunru"],
	["club", 8, "shezhanqunru"],
];

export default list;
