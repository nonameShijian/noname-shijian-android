const list = [
	["diamond", 1, "changshezhen"],
	["club", 1, "changshezhen"],
	// ["spade",1,'changshezhen'],
	// ["heart",1,'changshezhen'],

	["diamond", 2, "tianfuzhen"],
	// ["club",2,'tianfuzhen'],
	["spade", 2, "tianfuzhen"],
	["heart", 2, "tianfuzhen"],

	["diamond", 3, "dizaizhen"],
	// ["club",3,'dizaizhen'],
	["spade", 3, "dizaizhen"],
	["heart", 3, "dizaizhen"],

	// ["diamond",4,'fengyangzhen'],
	// ["club",4,'fengyangzhen'],
	// ["spade",4,'fengyangzhen'],
	// ["heart",4,'fengyangzhen'],

	// ["diamond",5,'zhonghuangzhen'],
	// ["club",5,'zhonghuangzhen'],
	// ["spade",5,'zhonghuangzhen'],
	// ["heart",5,'zhonghuangzhen'],

	// ["diamond",6,'huyizhen'],
	// ["club",6,'huyizhen'],
	// ["spade",6,'huyizhen'],
	// ["heart",6,'huyizhen'],

	["diamond", 7, "qixingzhen"],
	["club", 7, "qixingzhen"],
	["spade", 7, "qixingzhen"],
	// ["heart",7,'qixingzhen'],

	// ["diamond",8,'shepanzhen'],
	// ["club",8,'shepanzhen'],
	// ["spade",8,'shepanzhen'],
	// ["heart",8,'shepanzhen'],

	// ["diamond",9,'longfeizhen'],
	// ["club",9,'longfeizhen'],
	// ["spade",9,'longfeizhen'],
	// ["heart",9,'longfeizhen'],

	["diamond", 11, "niaoxiangzhen"],
	// ["club",11,'niaoxiangzhen'],
	["spade", 11, "niaoxiangzhen"],
	["heart", 11, "niaoxiangzhen"],

	// ["diamond",12,'yunchuizhen'],
	// ["club",12,'yunchuizhen'],
	// ["spade",12,'yunchuizhen'],
	// ["heart",12,'yunchuizhen'],

	// ["diamond",13,'pozhenjue'],
	// ["club",13,'pozhenjue'],
	// ["spade",13,'pozhenjue'],
	//["heart",13,'pozhenjue'],
];

export default list;
