const list = [
	["heart", 1, "hufu"],
	["spade", 1, "hufu"],
	["club", 1, "qiankundai"],

	["diamond", 3, "liuxinghuoyu", "fire"],
	["heart", 6, "liuxinghuoyu", "fire"],
	["heart", 9, "liuxinghuoyu", "fire"],

	["spade", 1, "baihupifeng"],
	["club", 1, "fengxueren"],
	["diamond", 1, "langeguaiyi"],
	["heart", 1, "daihuofenglun", "fire"],

	["diamond", 2, "xiayuncailing"],
	// ['heart',2,'huanpodan'],

	["club", 3, "caoyao"],
	["diamond", 3, "chilongya", "fire"],
	["spade", 3, "guiyoujie"],

	["club", 4, "caoyao"],
	["spade", 4, "zhufangshenshi"],
	// ['spade',4,'huanpodan'],

	["club", 5, "caoyao"],
	["spade", 5, "xixueguizhihuan"],
	// ['diamond',5,'huanpodan'],

	["club", 6, "shentoumianju"],
	["spade", 6, "yufulu"],

	["diamond", 7, "chiyuxi", "fire"],
	["club", 7, "jingleishan", "thunder"],
	["spade", 7, "guilingzhitao"],

	["spade", 8, "zhufangshenshi"],
	// ['club',8,'xiangyuye','poison'],

	["spade", 9, "yangpijuan"],
	["club", 9, "guiyoujie"],
	// ['diamond',9,'xiangyuye','poison'],

	// ['diamond',9,'tianxianjiu'],
	["heart", 9, "tianxianjiu"],
	["diamond", 2, "tianxianjiu"],

	["spade", 2, "qinglonglingzhu"],
	["spade", 7, "xingjunyan"],

	//['spade',10,'qipoguyu'],
	//['diamond',10,'xiangyuye','poison'],
	["club", 7, "yangpijuan"],

	// ['spade',11,'xiangyuye','poison'],

	["spade", 12, "guiyanfadao", "poison"],

	["spade", 13, "xianluhui"],
	["diamond", 3, "guangshatianyi"],
	["club", 13, "sadengjinhuan"],

	["club", 2, "lingjiandai"],
	// ['spade',3,'lingjiandai'],
	// ['heart',5,'lingjiandai'],
	["diamond", 8, "lingjiandai"],

	["club", 2, "jiguanshu"],
	// ['spade',2,'jiguanshu'],
	// ['heart',2,'jiguanshu'],
	["diamond", 2, "jiguanshu"],

	["club", 3, "jiguanyaoshu"],
	["spade", 3, "jiguanyaoshu"],
	// ['heart',3,'jiguanyaoshu'],
	// ['diamond',3,'jiguanyaoshu'],

	["spade", 4, "sifeizhenmian"],
	["heart", 13, "qinglianxindeng"],
	["club", 3, "jiguanyuan"],
	["diamond", 2, "jiguanyuan"],
	["diamond", 4, "jiguantong"],
	["club", 7, "jiguantong"],
	// ['spade',1,'shenmiguo'],
	["spade", 2, "shenmiguo"],
	["heart", 1, "shenmiguo"],
	["club", 3, "jiguanfeng"],
	["spade", 4, "jiguanfeng"],
	["spade", 9, "guisheqi"],
	["club", 7, "guisheqi"],

	["diamond", 13, "donghuangzhong"],
	["diamond", 13, "fuxiqin"],
	["spade", 13, "kunlunjingc"],
	["spade", 13, "xuanyuanjian"],
	["spade", 13, "pangufu"],
	["club", 13, "lianyaohu"],
	["diamond", 13, "haotianta"],
	["club", 13, "shennongding"],
	["heart", 13, "nvwashi"],
	["heart", 13, "kongdongyin"],

	["heart", 6, "qinglongzhigui"],
	["diamond", 6, "zhuquezhizhang"],
	["spade", 6, "baishouzhihu"],
	["club", 6, "xuanwuzhihuang"],
	["spade", 7, "cangchizhibi"],
	["heart", 5, "huanglinzhicong"],

	["spade", 9, "gouhunluo"],
	["club", 7, "gouhunluo"],

	["spade", 1, "xuejibingbao"],
	["club", 1, "xuejibingbao"],

	["heart", 3, "zhiluxiaohu"],
	["diamond", 4, "zhiluxiaohu"],

	["club", 7, "mujiaren"],
	["heart", 6, "mujiaren"],
	["diamond", 11, "mujiaren"],

	["club", 6, "shuchui"],

	// ['club',1,'fengyinzhidan'],
	// ['diamond',1,'fengyinzhidan'],
	// ['heart',1,'fengyinzhidan'],
	["spade", 1, "fengyinzhidan"],

	["heart", 9, "yuruyi"],

	["club", 4, "shencaojie"],
	["diamond", 4, "shencaojie"],
	["spade", 4, "shencaojie"],

	["spade", 1, "yuchanqian"],
	["club", 2, "yuchankun"],
	["diamond", 3, "yuchanzhen"],
	["heart", 4, "yuchanxun"],
	["spade", 5, "yuchankan"],
	["club", 6, "yuchanli"],
	["diamond", 7, "yuchangen"],
	["heart", 8, "yuchandui"],

	// ['spade',3,'dujian','poison'],
	// ['club',11,'dujian','poison'],
	// ['club',12,'dujian','poison'],
];

export default list;
