export default {
	hslingjian: 0.5,
	jiqi: 0.4,
	jiguan: 0.45,
};
