export default {
	land: 0.6,
};
