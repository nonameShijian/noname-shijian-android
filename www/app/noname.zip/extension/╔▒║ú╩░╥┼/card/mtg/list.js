const list = [
	["club", 12, "mtg_yixialan"],
	["spade", 11, "mtg_shuimomuxue"],
	["diamond", 5, "mtg_haidao"],
	["club", 10, "mtg_youlin"],
	["club", 8, "mtg_feixu"],
	["heart", 6, "mtg_shamolvzhou"],

	["club", 12, "mtg_cangbaohaiwan"],
	["spade", 11, "mtg_lindixiliu"],
	["diamond", 5, "mtg_bingheyaosai"],
	["club", 10, "mtg_longlushanfeng"],
	["club", 8, "mtg_duzhao"],
	["heart", 6, "mtg_linzhongjianta"],
];

export default list;
