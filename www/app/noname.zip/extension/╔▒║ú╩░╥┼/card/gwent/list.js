const list = [
	["club", 3, "gw_zhihuanjun"],
	["spade", 2, "gw_zhihuanjun"],

	["heart", 7, "gw_poxiao"],
	["diamond", 4, "gw_poxiao"],

	["spade", 9, "gw_aozuzhilei", "thunder"],
	["club", 7, "gw_aozuzhilei", "thunder"],

	["club", 1, "gw_zumoshoukao"],
	["spade", 1, "gw_zumoshoukao"],

	["diamond", 5, "gw_qinpendayu"],
	["club", 7, "gw_qinpendayu"],

	["spade", 9, "gw_birinongwu"],
	["heart", 13, "gw_birinongwu"],

	["diamond", 11, "gw_ciguhanshuang"],
	["club", 7, "gw_ciguhanshuang"],

	["heart", 4, "gw_baoxueyaoshui"],
	["spade", 8, "gw_baoxueyaoshui"],

	["spade", 8, "gw_shanbengshu"],
	["spade", 2, "gw_kunenfayin"],
	["club", 3, "gw_wenyi"],
	["heart", 8, "gw_yanziyaoshui"],
];

export default list;
