export default {
	spell: 0.5,
	spell_bronze: 0.2,
	spell_silver: 0.3,
	spell_gold: 0.4,
};
