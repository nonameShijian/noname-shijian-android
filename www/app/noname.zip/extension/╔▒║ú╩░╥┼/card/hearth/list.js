const list = [
	["heart", 2, "shenenshu"],
	["diamond", 12, "shenenshu"],
	["club", 7, "zhiliaobo"],
	["spade", 1, "zhiliaobo"],
	["spade", 13, "yuansuhuimie"],
	["spade", 13, "xingjiegoutong"],
	["diamond", 2, "tanshezhiren"],
	["diamond", 2, "chuansongmen"],
	["heart", 2, "chuansongmen"],
	["club", 3, "dunpaigedang"],
	["club", 3, "shandianjian", "thunder"],
	["spade", 1, "shandianjian", "thunder"],
	["spade", 7, "shijieshu"],
	["diamond", 5, "zhaomingdan"],
	["heart", 10, "zhaomingdan"],
	["diamond", 2, "jihuocard"],
	["diamond", 1, "linghunzhihuo"],
];

export default list;
