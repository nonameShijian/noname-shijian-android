const characterSort = {};

const characterSortTranslate = {};

export { characterSort, characterSortTranslate };
