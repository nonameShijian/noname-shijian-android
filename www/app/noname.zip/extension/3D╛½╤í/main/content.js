import { lib, game, ui, get, ai, _status } from "../../../noname.js";

export function content(config, pack) {
}
