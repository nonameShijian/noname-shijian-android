export { GameEvent as GameEventPromise } from "./gameEvent.js";
