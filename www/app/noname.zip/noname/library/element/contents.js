export const Contents = {
	// ? there's nothing, and there must have been nothing forever.
};
