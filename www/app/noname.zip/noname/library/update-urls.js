export const updateURLs = {
	coding: "https://unitedrhythmized.club/libccy/noname",
	github: "https://raw.githubusercontent.com/libnoname/noname",
};
